function [PSI]=phase_symmetry(t1,t2,T)
 PSI=(t1-t2)./T;
end