function [Ramp]=ratio_Amp(Ar,Al)
   Ramp=Ar./Al;
end
