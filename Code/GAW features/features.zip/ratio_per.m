function [Rper]=ratio_per(Pr,Pl)
  Rper=Pr./Pl;
end